package dev.febri.soundify;

import net.fabricmc.api.ClientModInitializer;

/**
 * Clean rebuild entrypoint.
 *
 * This scaffold intentionally does not yet register gameplay hooks.
 * Sound event routing and the custom configuration screen must be implemented
 * against the exact Minecraft 26.2/Fabric API mappings before release.
 */
public final class SoundifyRemakeClient implements ClientModInitializer {
    public static final String MOD_ID = "soundify_remake";

    @Override
    public void onInitializeClient() {
        // TODO: Register client-side event routing and the Soundify config screen.
    }
}
